package com.system.morapack.schemas;

public enum Continent {
    America,
    Europa,
    Asia
}
