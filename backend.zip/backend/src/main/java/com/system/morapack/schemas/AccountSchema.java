package com.system.morapack.schemas;

public class AccountSchema {
  
}
