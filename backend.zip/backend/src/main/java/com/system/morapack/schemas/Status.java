package com.system.morapack.schemas;

public enum Status {
    ASSIGNED,
    NOT_ASSIGNED,
    DELIVERED,
    NOT_DELIVERED;
}
