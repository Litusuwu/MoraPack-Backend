package com.system.morapack;

public class TestJPype {
    public static void main(String[] args) {
        System.out.println("TestJPype is running successfully!");
    }
    
    public static String testMethod() {
        return "TestJPype.testMethod() called successfully!";
    }
}
