package com.system.morapack.schemas;

public enum PackageStatus {
    PENDING,
    IN_TRANSIT,
    ARRIVED,
    DELIVERED,
    DELAYED
}
