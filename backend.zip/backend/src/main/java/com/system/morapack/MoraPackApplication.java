package com.system.morapack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoraPackApplication {

    public static void main(String[] args) {
        SpringApplication.run(MoraPackApplication.class, args);
    }

}
