package com.system.morapack.schemas;

public enum TypeUser {
  ADMIN, CUSTOMER, STAFF
}
