package com.system.morapack.schemas;

public enum AirportState {
    Avaiable,
    Restricted,
    Closed
}
